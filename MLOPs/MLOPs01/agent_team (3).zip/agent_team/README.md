# cross-verify — 3모델 교차검증 템플릿

**Claude + GPT + North** 가 한 과제를 같이 푼다. Claude가 초안을 쓰고, GPT·North가 **각자 tmux 페인에서** 비평하면, Claude가 모델 간 **합의**를 집계해 종합한다. 단독보다 견고해지는 걸 **pytest 점수 차이**로 눈으로 본다.

## 해보기 (한 줄)

```bash
tmux new -s dev && claude
```
Claude 안에서:
```
SPEC.md 구현해줘
```

그러면 자동으로:
1. 🔵 **Claude**가 채점 테스트 + 초안(`solo/`) 작성
2. 🟢 **GPT** · 🟣 **North** 팀메이트가 옆 페인에서 비평 → `SendMessage`로 회신
3. 🔵 **Claude**가 `consensus.py`로 합의 집계(2+ 모델이 같이 잡은 버그) → 종합(`crossverify/`)
4. 채점을 **두 축으로 분리** 보고 — ① 명세 기준선(`test_spec.py`, 보통 둘 다 통과) ② 교차검증 엣지(`test_crossverify.py`, 단독 vs 교차검증 차이). 자기충족 없이 "교차검증이 *추가로* 잡은 양"을 본다.

> 👀 핵심 볼거리: 서로 다른 페인에서 **다른 모델 에이전트들이 메시지로 상호작용**하는 것.

## 준비 (한 번)

- Claude Code · tmux · opencode 설치
- opencode 모델 인증: `opencode auth` (GPT는 OpenAI 로그인, North은 opencode 계정)
- Agent Teams는 `.claude/settings.json`에 이미 켜둠 (tmux 세션 안에서 `claude` 실행 필수)

> North(`opencode/north-mini-code-free`)은 opencode 무료·코드특화 모델이고 빠르다(no-tools 인라인이면 ~10초).
> ⚠ 리뷰어가 opencode 프롬프트에 **"파일 읽지 말고 도구 쓰지 마라" + 코드 인라인**을 넣어야 한다 — 안 넣으면 build 에이전트가 레포를 grep·재시도하며 헛돌아 수 분까지 늘어진다.
> 모델 ID는 환경마다 다를 수 있다 — 안 뜨면 `opencode models`로 확인 후 리뷰어 md의 `-m ...` 교체.

## 내 과제로 바꾸기

`SPEC.md`만 내 과제로 바꾸면 끝. 나머지는 그대로 동작한다.

## 파일 구성

```
SPEC.md                                   ★여기에 과제를 적는다
consensus.py                              모델 간 합의 집계(결정론) — python3 consensus.py --self-check
opencode.json                             리뷰어 read-only(안전)
.claude/settings.json                     Agent Teams 켜기
.claude/skills/cross-verify/SKILL.md      교차검증 절차(초안→비평→합의→종합→채점)
.claude/agents/opencode-gpt-reviewer.md
.claude/agents/opencode-north-reviewer.md
```
`solo/`·`crossverify/`·`test_spec.py`·`test_crossverify.py`·`findings.json`은 실행하면 자동 생성된다.
