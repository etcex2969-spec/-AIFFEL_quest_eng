#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""consensus.py — 리뷰어 비평을 '모델 간 합의'로 집계(결정론).

리드(Claude)가 GPT·Big Pickle 비평을 findings.json 으로 정규화해 넘기면,
같은 반례 입력(repro_input)을 몇 개 모델이 지적했는지 세어 합의/단독을 가른다.
  - 2+ 모델이 같은 입력을 문제삼음 → '합의'(우선 반영)
  - 1 모델만 지적          → '단독'(참고)
이종 모델에 strict JSON 을 강요하지 않으려고, 정규화는 리드가 하고 집계만 코드가 한다.

  python3 consensus.py findings.json
  python3 consensus.py --self-check

findings.json 형식: {"findings": [{"model": "...", "issue": "...", "repro_input": "..."}, ...]}
"""
import argparse
import json
import sys
from collections import defaultdict


def tally(findings):
    """repro_input 별로 지적한 모델을 모아 (합의[], 단독[]) 로 분리."""
    by_input = defaultdict(lambda: {"models": set(), "issues": []})
    for f in findings:
        key = (f.get("repro_input") or "").strip()
        if not key:
            continue  # 반례 입력 없는 지적은 집계 제외(자유 비평은 리드가 종합에서 흡수)
        g = by_input[key]
        g["models"].add(f.get("model", "?"))
        g["issues"].append(f.get("issue", ""))
    consensus, solo = [], []
    for inp, g in by_input.items():
        row = {"repro_input": inp, "models": sorted(g["models"]),
               "n": len(g["models"]), "issues": g["issues"]}
        (consensus if row["n"] >= 2 else solo).append(row)
    consensus.sort(key=lambda r: -r["n"])
    solo.sort(key=lambda r: r["repro_input"])
    return consensus, solo


def report(findings, n_models=3):
    consensus, solo = tally(findings)
    lines = [f"[합의 집계] 모델 {n_models}개 · 반례 지적 {sum(len(r['issues']) for r in consensus + solo)}건"]
    lines.append("\n■ 합의 (2+ 모델 — 우선 반영):")
    lines += ["  (없음)"] if not consensus else [
        f"  \"{r['repro_input']}\"  ← {', '.join(r['models'])} ({r['n']}/{n_models})" for r in consensus]
    lines.append("\n■ 단독 지적 (1 모델 — 참고):")
    lines += ["  (없음)"] if not solo else [
        f"  \"{r['repro_input']}\"  ← {r['models'][0]}" for r in solo]
    return "\n".join(lines), [r["repro_input"] for r in consensus]


def _self_check():
    f = [{"model": "gpt", "issue": "500ms를 500m으로 오파싱", "repro_input": "500ms"},
         {"model": "bigpickle", "issue": "ms 우선순위 누락", "repro_input": "500ms"},
         {"model": "gpt", "issue": "음수 미검증", "repro_input": "-1h"}]
    c, s = tally(f)
    assert [r["repro_input"] for r in c] == ["500ms"] and c[0]["n"] == 2, c
    assert len(s) == 1 and s[0]["repro_input"] == "-1h", s
    _, ci = report(f)
    assert ci == ["500ms"], ci
    assert tally([]) == ([], [])  # 빈 입력 안전
    print("[consensus] self-check OK")


def main():
    ap = argparse.ArgumentParser(description="모델 간 합의 집계(결정론).")
    ap.add_argument("findings", nargs="?", help="findings.json 경로.")
    ap.add_argument("--self-check", action="store_true")
    a = ap.parse_args()
    if a.self_check:
        return _self_check()
    if not a.findings:
        ap.error("findings.json 경로가 필요합니다(또는 --self-check).")
    data = json.load(open(a.findings, encoding="utf-8"))
    text, consensus_inputs = report(data.get("findings", []))
    print(text)
    print(f"\n→ 합의 입력 {len(consensus_inputs)}건은 test_spec.py 에 반드시 포함: {consensus_inputs}")


if __name__ == "__main__":
    main()
