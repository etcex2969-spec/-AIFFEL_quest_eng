---
name: cross-verify
description: >-
  SPEC.md의 빌드 과제를 Claude(팀 리드)·GPT·North 3개 모델로 교차검증해 단독보다 견고하게 구현한다.
  Claude가 초안을 만들고 GPT·North 팀메이트가 tmux 페인에서 독립 비평하면, 리드가 모델 간 합의로
  집계해 종합한다. 사용자가 "SPEC.md 구현해줘", "교차검증", "cross-verify", "다른 모델로도 검증/만들어"
  를 요청할 때 사용.
---

# cross-verify — 3모델 교차검증 빌드 (팀 리드 = 너, Claude)

너는 **팀 리드**다. `SPEC.md` 과제를 GPT·North 리뷰어와 교차검증해, 단일 모델이 놓치는 엣지케이스·버그를 잡는다. 리뷰어는 tmux 페인에서 도는 **별도 에이전트**다 — 비평은 그들이 `SendMessage`로 보내며, **너는 opencode를 직접 돌리지 않는다.**

## 0. 사전 점검
- **Agent Teams**: `.claude/settings.json`에 `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1`, `teammateMode:"tmux"`. **tmux 세션 안**(`$TMUX` 존재)에서 `claude`를 실행해야 팀메이트가 페인으로 보인다. 안 켜져 있으면 사용자에게 안내하고 멈춘다.
- 팀메이트 둘: `opencode-gpt-reviewer`, `opencode-north-reviewer`. 둘 다 분석 전용(`opencode.json`이 edit/bash deny), 비평을 `SendMessage(to:"team-lead")`로 보낸다. ⚠ 이 하네스에선 `to:"main"`이 거부되니(`"You are the main conversation"` 에러) 리뷰어는 **`team-lead`로 보낸다.**

## 1. 과제 읽기 + 채점 테스트 먼저 (🔵 리드)
1. `SPEC.md`를 읽는다.
2. **초안·비평을 보기 전에** `SPEC.md`만 근거로 **명세 기준선 테스트 `test_spec.py`** 를 작성한다(정상 + 엣지/잘못된 입력). 모듈은 환경변수로 받는다: `importlib.import_module(os.environ["SPEC_MODULE"])`.
   - **왜 먼저?** 테스트를 수정본 뒤에 짜면 점수가 자기충족이 된다. 명세 기준 테스트를 먼저 고정해야 객관적이다.
   - **이 파일은 비평을 본 뒤에도 절대 수정하지 않는다.** 리뷰어가 찾은 케이스는 4단계의 **별도 파일** `test_crossverify.py`로 간다. 그래야 "solo도 명세 기준은 통과(=무능하지 않음)"와 "교차검증이 *추가로* 잡은 것"이 분리돼 보인다.
   - 명세가 침묵하는 회색지대는 `# AMBIGUOUS` 주석으로 표시한다.
3. 채점 인터프리터 확정(기본 `python3`에 pytest가 없을 수 있다):
   ```bash
   for py in python3 python3.13 python3.12 python3.11; do "$py" -c "import pytest" 2>/dev/null && echo "PY=$py" && break; done
   ```

## 2. 초안 (🔵 리드)
네가 먼저 **초안 구현**을 작성해 **`solo/solution.py`** 에 저장한다(단독 1패스 = 비교 기준).

## 3. 팀메이트 스폰 → 독립 비평 (🟢 GPT · 🟣 North 병렬)
1. `Agent` 도구로 두 리뷰어를 **한 메시지에서 동시에** 스폰한다(각 페인 자동 생성). 스폰 프롬프트에 **명세·초안 파일 경로**를 명시하고 역할 경계를 못 박는다:
   > "너는 팀메이트다. 네 일반 텍스트 출력은 리드에게 **안 보인다.** 비평은 **오직 `SendMessage(to:\"team-lead\")` 호출로만** 보내라(이 하네스에선 `to:\"main\"`이 거부된다). opencode는 `-p` 없이 포그라운드 `timeout`으로 한 번만 돌려라."
2. **opencode를 네가 직접 돌리지 마라.** 리뷰어가 자기 페인에서 돌린다(협업 데모의 핵심 — 학생이 페인에서 상호작용을 본다).
3. 스폰 직후 **가드 타이머**(두 모델 모두 보통 수 초~수십 초):
   ```
   Bash(run_in_background): sleep 180; echo CROSSVERIFY_TIMEOUT
   ```
4. 둘의 `SendMessage` 비평이 **모두 도착**하거나 타이머가 울릴 때까지 기다린다. 한쪽만 와도 멈추지 말고 **받은 것만으로 진행**(미응답 리뷰어는 보고에 명시). 늦게 온 비평은 도착 즉시 반영.
   - ⚠ **종합(5단계)에 들어가기 직전, 받은 줄 알았던 메시지가 늦게 도착했을 수 있으니 한 번 더 기다렸다 인박스를 확인한다.** 미응답으로 단정하기 전에 nudge 후 최소 한 턴은 더 비운다 — 리뷰어가 `team-lead`로 보낸 비평이 종합 직전에 도착하는 경우가 있다.

## 4. 합의 집계 (🔵 리드 — 결정론)
받은 비평을 `findings.json`으로 정규화한다(리뷰어 항목 `- \`반례입력\` — 설명` 을 그대로 옮김):
```json
{"findings": [{"model": "gpt", "issue": "500ms를 500m으로 오파싱", "repro_input": "500ms"}, ...]}
```
그다음 합의를 코드로 집계한다(LLM 판단 X):
```bash
python3 consensus.py findings.json
```
- **2+ 모델이 같은 반례를 지적 = 합의** → 반드시 수정.
- **1 모델만 = 단독** → 타당하면 반영(참고).
- 반영하기로 한 (합의·단독) 케이스는 `test_spec.py`가 아니라 **`test_crossverify.py`** 에 넣는다(1단계 기준선과 분리).
- 합의는 **반례 입력 문자열 완전일치**로만 잡는다(결정론 유지 — 카테고리 묶기 같은 LLM 판단 금지). 그래서 **합의 0건이 정상일 수 있다**: 두 모델이 *서로 다른* 버그 클래스를 잡으면 합의가 아니라 **상보적 커버리지**다 — 이것도 교차검증의 정당한 성과이니 보고에 그렇게 적는다.

## 5. 종합 (🔵 리드)
합의 결과 + 받은 비평 + 네 판단을 종합해 초안을 고친 **최종본**을 **`crossverify/solution.py`** 에 저장한다. `# AMBIGUOUS`는 한 해석으로 확정하고 **보고에 명시**한다. 명세 밖 과잉(gold-plating)은 기각.

## 6. 채점 — 차이를 수치로 (★ 리드가 직접)
두 모듈을 **두 파일 모두**로 채점한다(기준선 + 교차검증 엣지):
```bash
for mod in solo.solution crossverify.solution; do
  SPEC_MODULE=$mod "$PY" -m pytest test_spec.py test_crossverify.py -q
done
```
보고는 **두 축을 분리**한다 — 자기충족 의심을 없애는 핵심:
- **명세 기준선(`test_spec.py`)**: 보통 solo·crossverify 둘 다 통과 → "solo도 무능하지 않다".
- **교차검증 엣지(`test_crossverify.py`)**: **"🔵 단독 N/M → 🟣 교차검증 M/M"** → 교차검증이 *추가로* 잡은 양.

## 7. 정리
- 두 리뷰어에 `shutdown_request`. 안 죽으면 `pkill -f "opencode run"`. 가드 타이머도 정리.

## 보고 형식
- **합의 / 단독 / 상보적** 구분 + `consensus.py` 집계 + **두 축 채점 수치(기준선 / 교차검증 엣지)** + 미응답 리뷰어·`AMBIGUOUS` 결정 명시.

## 주의
- ⚠ `opencode run`은 anomalyco 배포판 opencode다(Go 폐기판 `opencode -p`와 혼동 금지). "anomalyco"는 빌드 이름일 뿐 **모델 프리픽스가 아니다** — 모델 id는 리뷰어 md의 `-m` 뒤 문자열 그대로(`anomalyco/...` 금지).
- ⚠ 리뷰어 페인이 늘어지면 opencode build 에이전트가 레포를 grep·재시도하며 헛도는 것 — 리뷰어가 프롬프트에 "도구 쓰지 마라" + 코드 인라인을 넣었는지 확인(리뷰어 md에 박혀 있음).
- 리뷰어는 분석 전용. Agent Teams는 실험기능 → 버전별 차이 가능. LLM은 비결정적 → 차이는 **pytest로 객관 확정**한다.
